"""Independent RenderDragon material builder."""
